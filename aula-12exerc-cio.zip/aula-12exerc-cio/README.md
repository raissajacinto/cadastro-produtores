# Aula 12 - Exercício

A Pen created on CodePen.

Original URL: [https://codepen.io/raissavj/pen/OPMPapP](https://codepen.io/raissavj/pen/OPMPapP).

